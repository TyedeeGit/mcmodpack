// Creates a new event to allow the creation of new recipes
ServerEvents.recipes(event => {
    // New Enchanting Infuser Recipe

    event.shaped('enchantinginfuser:enchanting_infuser', [
        // Specifies structure of items
        'ABA',
        'BCB',
        'ABA'
    ],{
        // Specifies items required
        A: 'minecraft:amethyst_shard',
        B: 'minecraft:crying_obsidian',
        C: 'minecraft:enchanting_table'
    })
})

// Creates a new event to allow the removal of existing recipes
ServerEvents.recipes(event => {
    // Remove by Recipe ID
    [
        // Removes regular enchanting infuser recipe
        'enchantinginfuser:enchanting_infuser'

    ].forEach((RecipeID) => event.remove({id: RecipeID}));

    // Remove all recipes that take an item as an input (Not used atm)
    [

        ''

    ].forEach((IngredientID) => event.remove({input: IngredientID}));

    // Remove all recipes that give an item as an output
    [
        // Removes all possible recipes for advanced enchanting infuser
        'enchantinginfuser:advanced_enchanting_infuser'

    ].forEach((ItemID) => event.remove({output: ItemID}));
})
